def subtotal(prices):
    """Return the subtotal in integer cents."""
    return sum(round(price * 100) for price in prices)
