import unittest
from pricing import subtotal

class PricingTest(unittest.TestCase):
    def test_subtotal_cents(self):
        self.assertEqual(subtotal([1.25, 2.25]), 350)
        self.assertIsInstance(subtotal([1.25]), int)

if __name__ == '__main__':
    unittest.main()
